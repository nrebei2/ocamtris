# Ocamtris

A clone of Tetris made in OCaml made for Cornell CS 3110's final project.  
Developers: Noah Rebei (nr285), Jacobo Carreon (jic56), Noah Solomon (njs99), Richard Kang (rk695)